// TypeTuner MVP - 앱 로직

// 샘플 텍스트
const SAMPLE_TEXTS = {
    ko: {
        title: '타이포그래피는 콘텐츠의 숨결을 다스리는 디자인의 문법이다.',
        body: '타이포그래피는 콘텐츠의 숨결을 다스리는 디자인의 문법이다. 글자 하나하나의 선택이 읽기 경험을 좌우하며, 서체 간의 조화는 브랜드의 목소리를 형성한다. 잘 선택된 타이포그래피는 정보의 계층을 명확히 하고, 사용자의 시선을 자연스럽게 유도한다.',
        caption: 'Typography sets the rhythm of reading'
    },
    en: {
        title: 'Typography sets the rhythm of reading and the tone of brand voice.',
        body: 'Typography sets the rhythm of reading and the tone of brand voice. Each letterform choice influences the reading experience, and the harmony between typefaces shapes brand identity. Well-chosen typography clarifies information hierarchy and naturally guides the user\'s gaze.',
        caption: 'The art of type selection'
    }
};

// Google Fonts 매핑
const GOOGLE_FONTS_MAP = {
    "'Noto Sans KR', sans-serif": 'Noto+Sans+KR',
    "'Noto Serif KR', serif": 'Noto+Serif+KR',
    "'Merriweather', serif": 'Merriweather',
    "'Playfair Display', serif": 'Playfair+Display',
    "'Roboto', sans-serif": 'Roboto',
    "'Open Sans', sans-serif": 'Open+Sans',
    "'Lora', serif": 'Lora',
    "'Poppins', sans-serif": 'Poppins',
    "'Inter', sans-serif": 'Inter'
};

// 폰트 메타데이터 (카테고리, xHeight, width, variableFont)
// category: 'serif', 'sans-serif', 'display'
// xHeight: 0.4 ~ 0.6 (상대값)
// width: 'narrow', 'normal', 'wide' (1, 2, 3으로 표현)
// variableFont: 지원 축 배열 ['wght', 'wdth', 'slnt'] 또는 null
const FONT_METADATA = {
    "'Noto Sans KR', sans-serif": {
        category: 'sans-serif',
        xHeight: 0.52,
        width: 2,
        variableFont: null
    },
    "'Noto Serif KR', serif": {
        category: 'serif',
        xHeight: 0.48,
        width: 2,
        variableFont: null
    },
    "'Merriweather', serif": {
        category: 'serif',
        xHeight: 0.50,
        width: 2,
        variableFont: ['wght']
    },
    "'Playfair Display', serif": {
        category: 'display',
        xHeight: 0.45,
        width: 2,
        variableFont: null
    },
    "'Roboto', sans-serif": {
        category: 'sans-serif',
        xHeight: 0.55,
        width: 2,
        variableFont: ['wght', 'wdth']
    },
    "'Open Sans', sans-serif": {
        category: 'sans-serif',
        xHeight: 0.53,
        width: 2,
        variableFont: ['wght', 'wdth', 'slnt']
    },
    "'Lora', serif": {
        category: 'serif',
        xHeight: 0.51,
        width: 2,
        variableFont: null
    },
    "'Poppins', sans-serif": {
        category: 'sans-serif',
        xHeight: 0.54,
        width: 2,
        variableFont: ['wght']
    },
    "'Inter', sans-serif": {
        category: 'sans-serif',
        xHeight: 0.56,
        width: 2,
        variableFont: ['wght', 'slnt']
    }
};

// 레이아웃 프리셋 정의
const LAYOUT_PRESETS = {
    newspaper: {
        name: '신문형',
        title: {
            size: 48,
            lineHeight: 1.1,
            letterSpacing: -0.02
        },
        body: {
            size: 14,
            lineHeight: 1.8,
            letterSpacing: 0
        },
        caption: {
            size: 11,
            lineHeight: 1.5,
            letterSpacing: 0.01
        },
        maxWidth: 70
    },
    branding: {
        name: '브랜딩형',
        title: {
            size: 56,
            lineHeight: 1.0,
            letterSpacing: -0.03
        },
        body: {
            size: 18,
            lineHeight: 1.5,
            letterSpacing: 0.02
        },
        caption: {
            size: 12,
            lineHeight: 1.3,
            letterSpacing: 0.03
        },
        maxWidth: 55
    },
    subtitle: {
        name: '자막형',
        title: {
            size: 36,
            lineHeight: 1.3,
            letterSpacing: 0.01
        },
        body: {
            size: 16,
            lineHeight: 1.6,
            letterSpacing: 0.01
        },
        caption: {
            size: 14,
            lineHeight: 1.4,
            letterSpacing: 0.02
        },
        maxWidth: 60
    }
};

// 초기 상태
let currentState = {
    title: {
        fontFamily: "'Merriweather', serif",
        size: 42,
        lineHeight: 1.2,
        letterSpacing: 0,
        weight: 700,
        variableSettings: { wght: 700, wdth: 100, slnt: 0 }
    },
    body: {
        fontFamily: "'Noto Sans KR', sans-serif",
        size: 16,
        lineHeight: 1.6,
        letterSpacing: 0.01,
        weight: 400,
        variableSettings: { wght: 400, wdth: 100, slnt: 0 }
    },
    caption: {
        fontFamily: "'Noto Sans KR', sans-serif",
        size: 13,
        lineHeight: 1.4,
        letterSpacing: 0.02,
        weight: 400,
        variableSettings: { wght: 400, wdth: 100, slnt: 0 }
    },
    theme: 'dark',
    bgColor: '#1a1a1a',
    sampleLang: 'ko',
    sampleText: null,
    maxWidth: 65
};

let presets = [];

// DOM 요소 참조
const elements = {
    // 폰트 선택
    titleFont: document.getElementById('title-font'),
    titleWeight: document.getElementById('title-weight'),
    bodyFont: document.getElementById('body-font'),
    bodyWeight: document.getElementById('body-weight'),
    captionFont: document.getElementById('caption-font'),
    captionWeight: document.getElementById('caption-weight'),
    
    // 타이포 컨트롤
    titleSize: document.getElementById('title-size'),
    titleSizeValue: document.getElementById('title-size-value'),
    titleLineHeight: document.getElementById('title-lineheight'),
    titleLineHeightValue: document.getElementById('title-lineheight-value'),
    titleLetterSpacing: document.getElementById('title-letterspacing'),
    titleLetterSpacingValue: document.getElementById('title-letterspacing-value'),
    
    bodySize: document.getElementById('body-size'),
    bodySizeValue: document.getElementById('body-size-value'),
    bodyLineHeight: document.getElementById('body-lineheight'),
    bodyLineHeightValue: document.getElementById('body-lineheight-value'),
    bodyLetterSpacing: document.getElementById('body-letterspacing'),
    bodyLetterSpacingValue: document.getElementById('body-letterspacing-value'),
    bodyMaxWidth: document.getElementById('body-maxwidth'),
    bodyMaxWidthValue: document.getElementById('body-maxwidth-value'),
    
    captionSize: document.getElementById('caption-size'),
    captionSizeValue: document.getElementById('caption-size-value'),
    captionLineHeight: document.getElementById('caption-lineheight'),
    captionLineHeightValue: document.getElementById('caption-lineheight-value'),
    captionLetterSpacing: document.getElementById('caption-letterspacing'),
    captionLetterSpacingValue: document.getElementById('caption-letterspacing-value'),
    
    // 프리뷰
    previewTitle: document.getElementById('preview-title'),
    previewBody: document.getElementById('preview-body'),
    previewCaption: document.getElementById('preview-caption'),
    previewCanvas: document.getElementById('previewCanvas'),
    
    // 샘플 텍스트
    sampleKo: document.getElementById('sampleKo'),
    sampleEn: document.getElementById('sampleEn'),
    useCustomText: document.getElementById('useCustomText'),
    customTextInput: document.getElementById('customTextInput'),
    customTitleText: document.getElementById('customTitleText'),
    customBodyText: document.getElementById('customBodyText'),
    customCaptionText: document.getElementById('customCaptionText'),
    
    // 배경색
    bgColor: document.getElementById('bgColor'),
    bgColorText: document.getElementById('bgColorText'),
    
    // 테마
    themeToggle: document.getElementById('themeToggle'),
    
    // Export
    exportBtn: document.getElementById('exportBtn'),
    
    // 경고
    warnings: document.getElementById('warnings'),
    
    // 프리셋
    presetName: document.getElementById('presetName'),
    savePresetBtn: document.getElementById('savePresetBtn'),
    presetsList: document.getElementById('presetsList'),
    
    // 추천
    recommendBtn: document.getElementById('recommendBtn'),
    recommendationsPanel: document.getElementById('recommendationsPanel'),
    recommendationsList: document.getElementById('recommendationsList'),
    closeRecommendations: document.getElementById('closeRecommendations'),
    
    // Variable Font
    titleVariableControls: document.getElementById('title-variable-controls'),
    titleWght: document.getElementById('title-wght'),
    titleWghtValue: document.getElementById('title-wght-value'),
    titleWghtControl: document.getElementById('title-wght-control'),
    titleWdth: document.getElementById('title-wdth'),
    titleWdthValue: document.getElementById('title-wdth-value'),
    titleWdthControl: document.getElementById('title-wdth-control'),
    titleSlnt: document.getElementById('title-slnt'),
    titleSlntValue: document.getElementById('title-slnt-value'),
    titleSlntControl: document.getElementById('title-slnt-control'),
    
    bodyVariableControls: document.getElementById('body-variable-controls'),
    bodyWght: document.getElementById('body-wght'),
    bodyWghtValue: document.getElementById('body-wght-value'),
    bodyWghtControl: document.getElementById('body-wght-control'),
    bodyWdth: document.getElementById('body-wdth'),
    bodyWdthValue: document.getElementById('body-wdth-value'),
    bodyWdthControl: document.getElementById('body-wdth-control'),
    bodySlnt: document.getElementById('body-slnt'),
    bodySlntValue: document.getElementById('body-slnt-value'),
    bodySlntControl: document.getElementById('body-slnt-control'),
    
    captionVariableControls: document.getElementById('caption-variable-controls'),
    captionWght: document.getElementById('caption-wght'),
    captionWghtValue: document.getElementById('caption-wght-value'),
    captionWghtControl: document.getElementById('caption-wght-control'),
    captionWdth: document.getElementById('caption-wdth'),
    captionWdthValue: document.getElementById('caption-wdth-value'),
    captionWdthControl: document.getElementById('caption-wdth-control'),
    captionSlnt: document.getElementById('caption-slnt'),
    captionSlntValue: document.getElementById('caption-slnt-value'),
    captionSlntControl: document.getElementById('caption-slnt-control')
};

// 상태 로드
function loadState() {
    const saved = localStorage.getItem('typetuner-state');
    if (saved) {
        try {
            const loadedState = JSON.parse(saved);
            // Variable settings 기본값 보장
            ['title', 'body', 'caption'].forEach(slot => {
                if (!loadedState[slot].variableSettings) {
                    loadedState[slot].variableSettings = { 
                        wght: loadedState[slot].weight || (slot === 'title' ? 700 : 400), 
                        wdth: 100, 
                        slnt: 0 
                    };
                }
            });
            currentState = { ...currentState, ...loadedState };
        } catch (e) {
            console.error('Failed to load state:', e);
        }
    }
    
    loadPresets();
    applyStateToUI();
    updatePreview();
}

// 상태 저장
function saveState() {
    localStorage.setItem('typetuner-state', JSON.stringify(currentState));
}

// 프리셋 로드
function loadPresets() {
    const saved = localStorage.getItem('typetuner-presets');
    if (saved) {
        try {
            presets = JSON.parse(saved);
            renderPresets();
        } catch (e) {
            console.error('Failed to load presets:', e);
            presets = [];
        }
    }
}

// 프리셋 저장
function savePresets() {
    localStorage.setItem('typetuner-presets', JSON.stringify(presets));
}

// UI에 상태 적용
function applyStateToUI() {
    // 폰트 선택
    elements.titleFont.value = currentState.title.fontFamily;
    elements.titleWeight.value = currentState.title.weight;
    elements.bodyFont.value = currentState.body.fontFamily;
    elements.bodyWeight.value = currentState.body.weight;
    elements.captionFont.value = currentState.caption.fontFamily;
    elements.captionWeight.value = currentState.caption.weight;
    
    // 타이포 컨트롤
    elements.titleSize.value = currentState.title.size;
    elements.titleSizeValue.textContent = currentState.title.size;
    elements.titleLineHeight.value = currentState.title.lineHeight;
    elements.titleLineHeightValue.textContent = currentState.title.lineHeight;
    elements.titleLetterSpacing.value = currentState.title.letterSpacing;
    elements.titleLetterSpacingValue.textContent = currentState.title.letterSpacing;
    
    elements.bodySize.value = currentState.body.size;
    elements.bodySizeValue.textContent = currentState.body.size;
    elements.bodyLineHeight.value = currentState.body.lineHeight;
    elements.bodyLineHeightValue.textContent = currentState.body.lineHeight;
    elements.bodyLetterSpacing.value = currentState.body.letterSpacing;
    elements.bodyLetterSpacingValue.textContent = currentState.body.letterSpacing;
    elements.bodyMaxWidth.value = currentState.maxWidth;
    elements.bodyMaxWidthValue.textContent = currentState.maxWidth;
    
    elements.captionSize.value = currentState.caption.size;
    elements.captionSizeValue.textContent = currentState.caption.size;
    elements.captionLineHeight.value = currentState.caption.lineHeight;
    elements.captionLineHeightValue.textContent = currentState.caption.lineHeight;
    elements.captionLetterSpacing.value = currentState.caption.letterSpacing;
    elements.captionLetterSpacingValue.textContent = currentState.caption.letterSpacing;
    
    // 배경색
    elements.bgColor.value = currentState.bgColor;
    elements.bgColorText.value = currentState.bgColor;
    elements.previewCanvas.style.backgroundColor = currentState.bgColor;
    
    // 샘플 텍스트
    if (currentState.sampleLang === 'ko') {
        elements.sampleKo.classList.add('active');
        elements.sampleEn.classList.remove('active');
    } else {
        elements.sampleEn.classList.add('active');
        elements.sampleKo.classList.remove('active');
    }
    
    // 테마
    if (currentState.theme === 'light') {
        document.body.setAttribute('data-theme', 'light');
    } else {
        document.body.setAttribute('data-theme', 'dark');
    }
    
    // 커스텀 텍스트
    if (currentState.sampleText) {
        elements.useCustomText.checked = true;
        elements.customTextInput.style.display = 'flex';
        elements.customTitleText.value = currentState.sampleText.title || '';
        elements.customBodyText.value = currentState.sampleText.body || '';
        elements.customCaptionText.value = currentState.sampleText.caption || '';
    }
    
    // Variable Font 슬라이더 업데이트
    updateVariableControls('title');
    updateVariableControls('body');
    updateVariableControls('caption');
}

// Variable Font 컨트롤 표시/숨김
function updateVariableControls(slot) {
    const fontFamily = currentState[slot].fontFamily;
    const meta = FONT_METADATA[fontFamily];
    const variableSettings = currentState[slot].variableSettings || { wght: currentState[slot].weight || 400, wdth: 100, slnt: 0 };
    
    const controls = elements[`${slot}VariableControls`];
    const wghtControl = elements[`${slot}WghtControl`];
    const wdthControl = elements[`${slot}WdthControl`];
    const slntControl = elements[`${slot}SlntControl`];
    
    if (!meta || !meta.variableFont) {
        // Variable font 미지원
        controls.style.display = 'none';
        return;
    }
    
    // Variable font 지원 - 컨트롤 표시
    controls.style.display = 'block';
    
    // 각 축 표시/숨김
    if (meta.variableFont.includes('wght')) {
        wghtControl.style.display = 'block';
        const wght = elements[`${slot}Wght`];
        const wghtValue = elements[`${slot}WghtValue`];
        wght.value = variableSettings.wght;
        wghtValue.textContent = variableSettings.wght;
    } else {
        wghtControl.style.display = 'none';
    }
    
    if (meta.variableFont.includes('wdth')) {
        wdthControl.style.display = 'block';
        const wdth = elements[`${slot}Wdth`];
        const wdthValue = elements[`${slot}WdthValue`];
        wdth.value = variableSettings.wdth;
        wdthValue.textContent = variableSettings.wdth;
    } else {
        wdthControl.style.display = 'none';
    }
    
    if (meta.variableFont.includes('slnt')) {
        slntControl.style.display = 'block';
        const slnt = elements[`${slot}Slnt`];
        const slntValue = elements[`${slot}SlntValue`];
        slnt.value = variableSettings.slnt;
        slntValue.textContent = variableSettings.slnt;
    } else {
        slntControl.style.display = 'none';
    }
}

// font-variation-settings 적용
function applyVariableSettings(slot) {
    const fontFamily = currentState[slot].fontFamily;
    const meta = FONT_METADATA[fontFamily];
    const variableSettings = currentState[slot].variableSettings || { wght: currentState[slot].weight || 400, wdth: 100, slnt: 0 };
    
    if (!meta || !meta.variableFont) {
        return ''; // Variable font 미지원
    }
    
    const settings = [];
    if (meta.variableFont.includes('wght')) {
        settings.push(`"wght" ${variableSettings.wght}`);
    }
    if (meta.variableFont.includes('wdth')) {
        settings.push(`"wdth" ${variableSettings.wdth}`);
    }
    if (meta.variableFont.includes('slnt')) {
        settings.push(`"slnt" ${variableSettings.slnt}`);
    }
    
    return settings.length > 0 ? settings.join(', ') : '';
}

// Export용 Variable Font CSS 생성
function getVariableFontCSS(slot) {
    const fontFamily = currentState[slot].fontFamily;
    const meta = FONT_METADATA[fontFamily];
    const variableSettings = currentState[slot].variableSettings;
    
    if (!meta || !meta.variableFont || !variableSettings) {
        return '';
    }
    
    const settings = [];
    if (meta.variableFont.includes('wght') && variableSettings.wght !== undefined) {
        settings.push(`"wght" ${variableSettings.wght}`);
    }
    if (meta.variableFont.includes('wdth') && variableSettings.wdth !== undefined) {
        settings.push(`"wdth" ${variableSettings.wdth}`);
    }
    if (meta.variableFont.includes('slnt') && variableSettings.slnt !== undefined) {
        settings.push(`"slnt" ${variableSettings.slnt}`);
    }
    
    if (settings.length > 0) {
        return `  font-variation-settings: ${settings.join(', ')};`;
    }
    
    return '';
}

// 프리뷰 업데이트
function updatePreview() {
    const slot = currentState.sampleLang;
    const useCustom = elements.useCustomText.checked && 
                     (elements.customTitleText.value || elements.customBodyText.value || elements.customCaptionText.value);
    
    // Title
    elements.previewTitle.style.fontFamily = currentState.title.fontFamily;
    elements.previewTitle.style.fontSize = `${currentState.title.size}px`;
    elements.previewTitle.style.lineHeight = currentState.title.lineHeight;
    elements.previewTitle.style.letterSpacing = `${currentState.title.letterSpacing}em`;
    elements.previewTitle.style.fontWeight = currentState.title.weight;
    const titleVariable = applyVariableSettings('title');
    if (titleVariable) {
        elements.previewTitle.style.fontVariationSettings = titleVariable;
    } else {
        elements.previewTitle.style.fontVariationSettings = '';
    }
    elements.previewTitle.textContent = useCustom && elements.customTitleText.value
        ? elements.customTitleText.value
        : SAMPLE_TEXTS[slot].title;
    
    // Body
    elements.previewBody.style.fontFamily = currentState.body.fontFamily;
    elements.previewBody.style.fontSize = `${currentState.body.size}px`;
    elements.previewBody.style.lineHeight = currentState.body.lineHeight;
    elements.previewBody.style.letterSpacing = `${currentState.body.letterSpacing}em`;
    elements.previewBody.style.fontWeight = currentState.body.weight;
    const bodyVariable = applyVariableSettings('body');
    if (bodyVariable) {
        elements.previewBody.style.fontVariationSettings = bodyVariable;
    } else {
        elements.previewBody.style.fontVariationSettings = '';
    }
    elements.previewBody.style.maxWidth = `${currentState.maxWidth}ch`;
    elements.previewBody.textContent = useCustom && elements.customBodyText.value
        ? elements.customBodyText.value
        : SAMPLE_TEXTS[slot].body;
    
    // Caption
    elements.previewCaption.style.fontFamily = currentState.caption.fontFamily;
    elements.previewCaption.style.fontSize = `${currentState.caption.size}px`;
    elements.previewCaption.style.lineHeight = currentState.caption.lineHeight;
    elements.previewCaption.style.letterSpacing = `${currentState.caption.letterSpacing}em`;
    elements.previewCaption.style.fontWeight = currentState.caption.weight;
    const captionVariable = applyVariableSettings('caption');
    if (captionVariable) {
        elements.previewCaption.style.fontVariationSettings = captionVariable;
    } else {
        elements.previewCaption.style.fontVariationSettings = '';
    }
    elements.previewCaption.textContent = useCustom && elements.customCaptionText.value
        ? elements.customCaptionText.value
        : SAMPLE_TEXTS[slot].caption;
    
    // 배경색
    elements.previewCanvas.style.backgroundColor = currentState.bgColor;
    
    // Google Fonts 로드
    loadGoogleFonts();
    
    // 가독성 체크
    checkReadability();
}

// Google Fonts 로드
function loadGoogleFonts() {
    const fonts = new Set();
    fonts.add(currentState.title.fontFamily);
    fonts.add(currentState.body.fontFamily);
    fonts.add(currentState.caption.fontFamily);
    
    const fontNames = Array.from(fonts).map(f => {
        const googleName = GOOGLE_FONTS_MAP[f];
        if (!googleName) return null;
        return googleName;
    }).filter(Boolean);
    
    if (fontNames.length === 0) return;
    
    const weights = new Set();
    weights.add(currentState.title.weight);
    weights.add(currentState.body.weight);
    weights.add(currentState.caption.weight);
    const weightStr = Array.from(weights).join(';');
    
    const linkId = 'google-fonts-link';
    let link = document.getElementById(linkId);
    
    if (!link) {
        link = document.createElement('link');
        link.id = linkId;
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    }
    
    const fontQuery = fontNames.map(f => `${f}:wght@${weightStr}`).join('&family=');
    link.href = `https://fonts.googleapis.com/css2?family=${fontQuery}&display=swap`;
}

// 가독성 체크
function checkReadability() {
    const warnings = [];
    
    // Body 크기 체크
    if (currentState.body.size < 16) {
        warnings.push({
            type: 'warning',
            message: `본문 크기가 ${currentState.body.size}px입니다. 가독성을 위해 16px 이상을 권장합니다.`
        });
    } else {
        warnings.push({
            type: 'success',
            message: `본문 크기 ${currentState.body.size}px는 적절합니다.`
        });
    }
    
    // Body 행간 체크
    if (currentState.body.lineHeight < 1.5) {
        warnings.push({
            type: 'warning',
            message: `본문 행간이 ${currentState.body.lineHeight}입니다. 가독성을 위해 1.5 이상을 권장합니다.`
        });
    } else {
        warnings.push({
            type: 'success',
            message: `본문 행간 ${currentState.body.lineHeight}는 적절합니다.`
        });
    }
    
    // 열폭 체크
    if (currentState.maxWidth < 45 || currentState.maxWidth > 75) {
        warnings.push({
            type: 'warning',
            message: `본문 열폭이 ${currentState.maxWidth}ch입니다. 권장 범위는 45-75ch입니다.`
        });
    } else {
        warnings.push({
            type: 'success',
            message: `본문 열폭 ${currentState.maxWidth}ch는 적절합니다.`
        });
    }
    
    // 대비 체크 (간단한 흑백 체크)
    const bgColor = currentState.bgColor;
    const isDarkBg = isDarkColor(bgColor);
    const textColor = isDarkBg ? '#ffffff' : '#000000';
    const contrast = getContrastRatio(textColor, bgColor);
    
    if (contrast < 4.5) {
        warnings.push({
            type: 'warning',
            message: `텍스트-배경 대비가 낮습니다 (약 ${contrast.toFixed(1)}:1). WCAG AA 권장 대비는 4.5:1입니다.`
        });
    } else {
        warnings.push({
            type: 'success',
            message: `텍스트-배경 대비가 적절합니다 (약 ${contrast.toFixed(1)}:1).`
        });
    }
    
    renderWarnings(warnings);
}

// 색상 밝기 체크
function isDarkColor(color) {
    const hex = color.replace('#', '');
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    const brightness = (r * 299 + g * 587 + b * 114) / 1000;
    return brightness < 128;
}

// 대비 비율 계산 (간단한 버전)
function getContrastRatio(color1, color2) {
    const getLuminance = (color) => {
        const hex = color.replace('#', '');
        const r = parseInt(hex.substr(0, 2), 16) / 255;
        const g = parseInt(hex.substr(2, 2), 16) / 255;
        const b = parseInt(hex.substr(4, 2), 16) / 255;
        
        const [r2, g2, b2] = [r, g, b].map(val => {
            return val <= 0.03928 ? val / 12.92 : Math.pow((val + 0.055) / 1.055, 2.4);
        });
        
        return 0.2126 * r2 + 0.7152 * g2 + 0.0722 * b2;
    };
    
    const l1 = getLuminance(color1);
    const l2 = getLuminance(color2);
    
    const lighter = Math.max(l1, l2);
    const darker = Math.min(l1, l2);
    
    return (lighter + 0.05) / (darker + 0.05);
}

// 경고 렌더링
function renderWarnings(warnings) {
    elements.warnings.innerHTML = warnings.map(w => `
        <div class="warning-item ${w.type}">
            <span>${w.type === 'warning' ? '⚠️' : '✓'}</span>
            <span>${w.message}</span>
        </div>
    `).join('');
}

// Export CSS
function exportCSS() {
    // 폰트별 정보 수집 (weight, variable axes)
    const fontData = {};
    const fonts = [
        { slot: 'title', family: currentState.title.fontFamily, weight: currentState.title.weight, variableSettings: currentState.title.variableSettings },
        { slot: 'body', family: currentState.body.fontFamily, weight: currentState.body.weight, variableSettings: currentState.body.variableSettings },
        { slot: 'caption', family: currentState.caption.fontFamily, weight: currentState.caption.weight, variableSettings: currentState.caption.variableSettings }
    ];
    
    fonts.forEach(({ family, weight, variableSettings, slot }) => {
        if (!fontData[family]) {
            fontData[family] = {
                weights: new Set(),
                variableAxes: new Set(),
                meta: FONT_METADATA[family]
            };
        }
        fontData[family].weights.add(weight);
        
        // Variable font 축 정보 수집
        if (variableSettings && fontData[family].meta && fontData[family].meta.variableFont) {
            const axes = [];
            if (fontData[family].meta.variableFont.includes('wght') && variableSettings.wght) {
                axes.push(`wght@${variableSettings.wght}`);
            }
            if (fontData[family].meta.variableFont.includes('wdth') && variableSettings.wdth) {
                axes.push(`wdth@${variableSettings.wdth}`);
            }
            if (fontData[family].meta.variableFont.includes('slnt') && variableSettings.slnt !== undefined) {
                axes.push(`slnt@${variableSettings.slnt}`);
            }
            if (axes.length > 0) {
                fontData[family].variableAxes.add(axes.join(','));
            }
        }
    });
    
    // Google Fonts 링크 생성
    const fontQueries = [];
    const fontQueriesVariable = [];
    
    Object.keys(fontData).forEach(fontFamily => {
        const googleName = GOOGLE_FONTS_MAP[fontFamily];
        if (!googleName) return;
        
        const data = fontData[fontFamily];
        const meta = data.meta;
        
        // Variable font 지원하는 경우
        if (meta && meta.variableFont && data.variableAxes.size > 0) {
            // Variable font 축 범위로 링크 생성
            const axisParts = [];
            if (meta.variableFont.includes('wght')) {
                const weights = Array.from(data.weights).sort((a, b) => a - b);
                const minWeight = Math.min(...weights, 100);
                const maxWeight = Math.max(...weights, 900);
                axisParts.push(`wght@${minWeight}..${maxWeight}`);
            }
            if (meta.variableFont.includes('wdth')) {
                axisParts.push('wdth@75..125');
            }
            if (meta.variableFont.includes('slnt')) {
                axisParts.push('slnt@-15..0');
            }
            if (axisParts.length > 0) {
                fontQueriesVariable.push(`${googleName}:${axisParts.join(',')}`);
            }
        } else {
            // 일반 font weight만
            const weights = Array.from(data.weights).sort((a, b) => a - b);
            const weightStr = weights.join(';');
            fontQueries.push(`${googleName}:wght@${weightStr}`);
        }
    });
    
    // 모든 쿼리 결합
    const allQueries = [...fontQueries, ...fontQueriesVariable];
    
    const googleFontsLink = allQueries.length > 0
        ? `<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=${allQueries.join('&family=')}&display=swap" rel="stylesheet">`
        : '';
    
    const googleFontsImport = allQueries.length > 0
        ? `@import url('https://fonts.googleapis.com/css2?family=${allQueries.join('&family=')}&display=swap');`
        : '';
    
    // CSS 생성
    const css = `/* TypeTuner Export CSS */
/* Generated: ${new Date().toLocaleString('ko-KR')} */

/* Google Fonts - Link 태그 방식 (HTML <head>에 추가) */
${googleFontsLink ? googleFontsLink : '<!-- Google Fonts를 사용하지 않습니다 -->'}

/* Google Fonts - @import 방식 (CSS 파일 상단에 추가) */
${googleFontsImport ? googleFontsImport : '/* Google Fonts를 사용하지 않습니다 */'}

/* CSS Variables */
:root {
  --tt-title-font: ${currentState.title.fontFamily};
  --tt-title-size: ${currentState.title.size}px;
  --tt-title-line-height: ${currentState.title.lineHeight};
  --tt-title-letter-spacing: ${currentState.title.letterSpacing}em;
  --tt-title-weight: ${currentState.title.weight};
  
  --tt-body-font: ${currentState.body.fontFamily};
  --tt-body-size: ${currentState.body.size}px;
  --tt-body-line-height: ${currentState.body.lineHeight};
  --tt-body-letter-spacing: ${currentState.body.letterSpacing}em;
  --tt-body-weight: ${currentState.body.weight};
  --tt-body-max-width: ${currentState.maxWidth}ch;
  
  --tt-caption-font: ${currentState.caption.fontFamily};
  --tt-caption-size: ${currentState.caption.size}px;
  --tt-caption-line-height: ${currentState.caption.lineHeight};
  --tt-caption-letter-spacing: ${currentState.caption.letterSpacing}em;
  --tt-caption-weight: ${currentState.caption.weight};
}

/* Title Styles */
.tt-title {
  font-family: var(--tt-title-font);
  font-size: var(--tt-title-size);
  line-height: var(--tt-title-line-height);
  letter-spacing: var(--tt-title-letter-spacing);
  font-weight: var(--tt-title-weight);
${getVariableFontCSS('title')}}

/* Body Styles */
.tt-body {
  font-family: var(--tt-body-font);
  font-size: var(--tt-body-size);
  line-height: var(--tt-body-line-height);
  letter-spacing: var(--tt-body-letter-spacing);
  font-weight: var(--tt-body-weight);
  max-width: var(--tt-body-max-width);
${getVariableFontCSS('body')}}

/* Caption Styles */
.tt-caption {
  font-family: var(--tt-caption-font);
  font-size: var(--tt-caption-size);
  line-height: var(--tt-caption-line-height);
  letter-spacing: var(--tt-caption-letter-spacing);
  font-weight: var(--tt-caption-weight);
${getVariableFontCSS('caption')}}

/* 인라인 스타일 방식 (CSS 변수 미사용 시) */
/*
.title {
  font-family: ${currentState.title.fontFamily};
  font-size: ${currentState.title.size}px;
  line-height: ${currentState.title.lineHeight};
  letter-spacing: ${currentState.title.letterSpacing}em;
  font-weight: ${currentState.title.weight};
${getVariableFontCSS('title')}
}

.body {
  font-family: ${currentState.body.fontFamily};
  font-size: ${currentState.body.size}px;
  line-height: ${currentState.body.lineHeight};
  letter-spacing: ${currentState.body.letterSpacing}em;
  font-weight: ${currentState.body.weight};
  max-width: ${currentState.maxWidth}ch;
${getVariableFontCSS('body')}
}

.caption {
  font-family: ${currentState.caption.fontFamily};
  font-size: ${currentState.caption.size}px;
  line-height: ${currentState.caption.lineHeight};
  letter-spacing: ${currentState.caption.letterSpacing}em;
  font-weight: ${currentState.caption.weight};
${getVariableFontCSS('caption')}
}
*/`;
    
    // 클립보드에 복사
    const copyToClipboard = async () => {
        try {
            // 최신 브라우저 API 사용
            if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText(css);
                return true;
            } else {
                // 폴백: 구형 브라우저 지원
                const textarea = document.createElement('textarea');
                textarea.value = css;
                textarea.style.position = 'fixed';
                textarea.style.opacity = '0';
                textarea.style.left = '-999999px';
                document.body.appendChild(textarea);
                textarea.focus();
                textarea.select();
                
                try {
                    const successful = document.execCommand('copy');
                    document.body.removeChild(textarea);
                    return successful;
                } catch (err) {
                    document.body.removeChild(textarea);
                    return false;
                }
            }
        } catch (err) {
            console.error('클립보드 복사 실패:', err);
            return false;
        }
    };
    
    copyToClipboard().then(success => {
        if (success) {
            // 성공 메시지 (간단한 토스트 메시지 스타일)
            const message = document.createElement('div');
            message.textContent = '✓ CSS가 클립보드에 복사되었습니다!';
            message.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: var(--success);
                color: white;
                padding: 1rem 1.5rem;
                border-radius: 6px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                z-index: 10000;
                font-weight: 500;
                animation: slideIn 0.3s ease-out;
            `;
            
            // 애니메이션 추가
            const style = document.createElement('style');
            style.textContent = `
                @keyframes slideIn {
                    from {
                        transform: translateX(400px);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
            `;
            document.head.appendChild(style);
            
            document.body.appendChild(message);
            
            setTimeout(() => {
                message.style.opacity = '0';
                message.style.transition = 'opacity 0.3s';
                setTimeout(() => {
                    document.body.removeChild(message);
                    document.head.removeChild(style);
                }, 300);
            }, 2000);
        } else {
            // 실패 시 기본 alert
            alert('클립보드 복사에 실패했습니다. CSS를 직접 복사해주세요.\n\n' + css.substring(0, 200) + '...');
        }
    });
}

// 폰트 페어링 추천 함수
function calculatePairingScore(titleFont, bodyFont, captionFont) {
    const titleMeta = FONT_METADATA[titleFont];
    const bodyMeta = FONT_METADATA[bodyFont];
    const captionMeta = FONT_METADATA[captionFont];
    
    if (!titleMeta || !bodyMeta || !captionMeta) return 0;
    
    let score = 0;
    const reasons = [];
    
    // Base 점수
    score += 1;
    
    // SerifMix: 헤드라인은 세리프/디스플레이, 본문은 산세리프 선호 (1~2점)
    const serifMix = (
        (titleMeta.category === 'serif' || titleMeta.category === 'display') &&
        bodyMeta.category === 'sans-serif'
    ) ? 2 : (
        (titleMeta.category === 'serif' || titleMeta.category === 'display') ? 1 : 0
    );
    score += serifMix;
    if (serifMix > 0) {
        reasons.push(`세리프 헤드라인 + 산세리프 본문 조합`);
    }
    
    // WeightContrast: Title > Body > Caption 대비 (0~2점)
    const titleWeight = currentState.title.weight || 700;
    const bodyWeight = currentState.body.weight || 400;
    const captionWeight = currentState.caption.weight || 400;
    
    let weightContrast = 0;
    if (titleWeight > bodyWeight) weightContrast += 1;
    if (bodyWeight >= captionWeight) weightContrast += 1;
    score += weightContrast;
    if (weightContrast > 0) {
        reasons.push(`적절한 굵기 대비`);
    }
    
    // XHeightContrast: x-height 높은 본문 서체 + 대비 명확한 헤드라인 (0~2점)
    const xHeightContrast = Math.abs(bodyMeta.xHeight - titleMeta.xHeight);
    const xHeightScore = xHeightContrast > 0.05 ? 2 : (xHeightContrast > 0.02 ? 1 : 0);
    score += xHeightScore;
    if (bodyMeta.xHeight > 0.5) {
        reasons.push(`높은 본문 x-height`);
    }
    
    // CategoryDiversity: 카테고리 다양성 (0~1점)
    const categories = new Set([titleMeta.category, bodyMeta.category, captionMeta.category]);
    const categoryDiversity = categories.size === 3 ? 1 : (categories.size === 2 ? 0.5 : 0);
    score += categoryDiversity;
    if (categoryDiversity > 0) {
        reasons.push(`카테고리 다양성`);
    }
    
    return { score, reasons };
}

// 상위 3조합 추천 생성
function generateRecommendations() {
    const availableFonts = Object.keys(FONT_METADATA);
    const recommendations = [];
    
    // 모든 가능한 조합 생성 (Title, Body, Caption)
    for (const titleFont of availableFonts) {
        for (const bodyFont of availableFonts) {
            for (const captionFont of availableFonts) {
                // Caption은 보통 Body와 같거나 비슷한 폰트 사용
                if (captionFont !== bodyFont && captionFont !== titleFont) continue;
                
                const { score, reasons } = calculatePairingScore(titleFont, bodyFont, captionFont);
                
                if (score > 0) {
                    recommendations.push({
                        titleFont,
                        bodyFont,
                        captionFont,
                        score,
                        reasons,
                        titleMeta: FONT_METADATA[titleFont],
                        bodyMeta: FONT_METADATA[bodyFont],
                        captionMeta: FONT_METADATA[captionFont]
                    });
                }
            }
        }
    }
    
    // 점수순으로 정렬하고 상위 3개 선택
    recommendations.sort((a, b) => b.score - a.score);
    return recommendations.slice(0, 3);
}

// 추천 결과 렌더링
function renderRecommendations() {
    const recommendations = generateRecommendations();
    
    if (recommendations.length === 0) {
        elements.recommendationsList.innerHTML = '<p style="color: var(--text-secondary); padding: 2rem; text-align: center;">추천할 조합을 찾을 수 없습니다.</p>';
        return;
    }
    
    // recommendations를 전역에 저장 (이벤트 핸들러에서 접근하기 위해)
    window.currentRecommendations = recommendations;
    
    elements.recommendationsList.innerHTML = recommendations.map((rec, index) => {
        const titleName = rec.titleFont.replace(/'/g, '').replace(', serif', '').replace(', sans-serif', '');
        const bodyName = rec.bodyFont.replace(/'/g, '').replace(', serif', '').replace(', sans-serif', '');
        const captionName = rec.captionFont.replace(/'/g, '').replace(', serif', '').replace(', sans-serif', '');
        
        return `
            <div class="recommendation-card">
                <div class="recommendation-card-header">
                    <h3>추천 ${index + 1}</h3>
                    <span class="recommendation-score">점수: ${rec.score.toFixed(1)}</span>
                </div>
                <div class="recommendation-pairing">
                    <div class="pairing-item">
                        <strong>Title:</strong> ${titleName}
                        <span class="category-badge">${rec.titleMeta.category}</span>
                    </div>
                    <div class="pairing-item">
                        <strong>Body:</strong> ${bodyName}
                        <span class="category-badge">${rec.bodyMeta.category}</span>
                    </div>
                    <div class="pairing-item">
                        <strong>Caption:</strong> ${captionName}
                        <span class="category-badge">${rec.captionMeta.category}</span>
                    </div>
                </div>
                <div class="recommendation-reasons">
                    <strong>추천 이유:</strong>
                    <div class="reason-badges">
                        ${rec.reasons.map(reason => `<span class="reason-badge">${reason}</span>`).join('')}
                    </div>
                </div>
                <button class="btn-primary apply-pairing-btn" data-index="${index}">
                    이 조합 적용
                </button>
            </div>
        `;
    }).join('');
    
    // 적용 버튼 이벤트
    document.querySelectorAll('.apply-pairing-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const index = parseInt(btn.dataset.index);
            applyRecommendation(window.currentRecommendations[index]);
        });
    });
}

// 추천 조합 적용
function applyRecommendation(recommendation) {
    currentState.title.fontFamily = recommendation.titleFont;
    currentState.body.fontFamily = recommendation.bodyFont;
    currentState.caption.fontFamily = recommendation.captionFont;
    
    // 적절한 weight 설정
    if (recommendation.titleMeta.category === 'serif' || recommendation.titleMeta.category === 'display') {
        currentState.title.weight = 700;
    }
    if (recommendation.bodyMeta.category === 'sans-serif') {
        currentState.body.weight = 400;
    }
    currentState.caption.weight = 400;
    
    applyStateToUI();
    updatePreview();
    saveState();
    
    // 추천 패널 닫기
    elements.recommendationsPanel.style.display = 'none';
    
    // 성공 메시지
    const message = document.createElement('div');
    message.textContent = '✓ 추천 조합이 적용되었습니다!';
    message.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--success);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 6px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        z-index: 10000;
        font-weight: 500;
    `;
    document.body.appendChild(message);
    setTimeout(() => {
        message.style.opacity = '0';
        message.style.transition = 'opacity 0.3s';
        setTimeout(() => document.body.removeChild(message), 300);
    }, 2000);
}

// 레이아웃 프리셋 적용
function applyLayoutPreset(presetKey) {
    const preset = LAYOUT_PRESETS[presetKey];
    if (!preset) return;
    
    // Title 설정 적용
    currentState.title.size = preset.title.size;
    currentState.title.lineHeight = preset.title.lineHeight;
    currentState.title.letterSpacing = preset.title.letterSpacing;
    
    // Body 설정 적용
    currentState.body.size = preset.body.size;
    currentState.body.lineHeight = preset.body.lineHeight;
    currentState.body.letterSpacing = preset.body.letterSpacing;
    
    // Caption 설정 적용
    currentState.caption.size = preset.caption.size;
    currentState.caption.lineHeight = preset.caption.lineHeight;
    currentState.caption.letterSpacing = preset.caption.letterSpacing;
    
    // Max width 적용
    currentState.maxWidth = preset.maxWidth;
    
    // UI 업데이트
    applyStateToUI();
    updatePreview();
    saveState();
    
    // 피드백 메시지
    const message = document.createElement('div');
    message.textContent = `✓ ${preset.name} 레이아웃이 적용되었습니다!`;
    message.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--success);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 6px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        z-index: 10000;
        font-weight: 500;
    `;
    document.body.appendChild(message);
    setTimeout(() => {
        message.style.opacity = '0';
        message.style.transition = 'opacity 0.3s';
        setTimeout(() => document.body.removeChild(message), 300);
    }, 2000);
}

// 프리셋 저장
function savePreset() {
    const name = elements.presetName.value.trim();
    if (!name) {
        alert('프리셋 이름을 입력해주세요.');
        return;
    }
    
    const preset = {
        id: Date.now().toString(),
        name: name,
        state: JSON.parse(JSON.stringify(currentState)),
        createdAt: Date.now(),
        updatedAt: Date.now()
    };
    
    presets.push(preset);
    savePresets();
    renderPresets();
    elements.presetName.value = '';
}

// 프리셋 삭제
function deletePreset(id) {
    if (confirm('이 프리셋을 삭제하시겠습니까?')) {
        presets = presets.filter(p => p.id !== id);
        savePresets();
        renderPresets();
    }
}

// 프리셋 로드
function loadPreset(id) {
    const preset = presets.find(p => p.id === id);
    if (!preset) return;
    
    currentState = JSON.parse(JSON.stringify(preset.state));
    // Variable settings 기본값 보장
    ['title', 'body', 'caption'].forEach(slot => {
        if (!currentState[slot].variableSettings) {
            currentState[slot].variableSettings = { 
                wght: currentState[slot].weight || (slot === 'title' ? 700 : 400), 
                wdth: 100, 
                slnt: 0 
            };
        }
    });
    applyStateToUI();
    updatePreview();
    saveState();
}

// 프리셋 수정
function editPreset(id) {
    const preset = presets.find(p => p.id === id);
    if (!preset) return;
    
    const newName = prompt('새 프리셋 이름을 입력하세요:', preset.name);
    if (!newName || !newName.trim()) return;
    
    preset.name = newName.trim();
    preset.state = JSON.parse(JSON.stringify(currentState));
    preset.updatedAt = Date.now();
    
    savePresets();
    renderPresets();
}

// 프리셋 렌더링
function renderPresets() {
    if (presets.length === 0) {
        elements.presetsList.innerHTML = '<p style="color: var(--text-secondary); font-style: italic;">저장된 프리셋이 없습니다.</p>';
        return;
    }
    
    elements.presetsList.innerHTML = presets.map(preset => {
        const date = new Date(preset.updatedAt);
        const dateStr = date.toLocaleDateString('ko-KR', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        return `
            <div class="preset-card">
                <div class="preset-card-header">
                    <span class="preset-card-name">${preset.name}</span>
                    <div class="preset-card-actions">
                        <button class="btn-primary btn-small" onclick="loadPreset('${preset.id}')">불러오기</button>
                        <button class="btn-secondary btn-small" onclick="editPreset('${preset.id}')">수정</button>
                        <button class="btn-danger btn-small" onclick="deletePreset('${preset.id}')">삭제</button>
                    </div>
                </div>
                <div class="preset-card-date">수정: ${dateStr}</div>
                <div class="preset-card-preview">
                    Title: ${preset.state.title.fontFamily.replace(/'/g, '')}, 
                    Body: ${preset.state.body.fontFamily.replace(/'/g, '')}
                </div>
            </div>
        `;
    }).join('');
}

// 이벤트 리스너 설정
function setupEventListeners() {
    // 폰트 변경
    elements.titleFont.addEventListener('change', (e) => {
        currentState.title.fontFamily = e.target.value;
        // Variable font 기본값 설정
        const meta = FONT_METADATA[e.target.value];
        if (meta && meta.variableFont) {
            if (!currentState.title.variableSettings) {
                currentState.title.variableSettings = { wght: currentState.title.weight || 700, wdth: 100, slnt: 0 };
            }
        }
        updateVariableControls('title');
        updatePreview();
        saveState();
    });
    
    elements.titleWeight.addEventListener('change', (e) => {
        currentState.title.weight = parseInt(e.target.value);
        updatePreview();
        saveState();
    });
    
    elements.bodyFont.addEventListener('change', (e) => {
        currentState.body.fontFamily = e.target.value;
        // Variable font 기본값 설정
        const meta = FONT_METADATA[e.target.value];
        if (meta && meta.variableFont) {
            if (!currentState.body.variableSettings) {
                currentState.body.variableSettings = { wght: currentState.body.weight || 400, wdth: 100, slnt: 0 };
            }
        }
        updateVariableControls('body');
        updatePreview();
        saveState();
    });
    
    elements.bodyWeight.addEventListener('change', (e) => {
        currentState.body.weight = parseInt(e.target.value);
        updatePreview();
        saveState();
    });
    
    elements.captionFont.addEventListener('change', (e) => {
        currentState.caption.fontFamily = e.target.value;
        // Variable font 기본값 설정
        const meta = FONT_METADATA[e.target.value];
        if (meta && meta.variableFont) {
            if (!currentState.caption.variableSettings) {
                currentState.caption.variableSettings = { wght: currentState.caption.weight || 400, wdth: 100, slnt: 0 };
            }
        }
        updateVariableControls('caption');
        updatePreview();
        saveState();
    });
    
    elements.captionWeight.addEventListener('change', (e) => {
        currentState.caption.weight = parseInt(e.target.value);
        updatePreview();
        saveState();
    });
    
    // 타이포 컨트롤
    elements.titleSize.addEventListener('input', (e) => {
        currentState.title.size = parseInt(e.target.value);
        elements.titleSizeValue.textContent = currentState.title.size;
        updatePreview();
        saveState();
    });
    
    elements.titleLineHeight.addEventListener('input', (e) => {
        currentState.title.lineHeight = parseFloat(e.target.value);
        elements.titleLineHeightValue.textContent = currentState.title.lineHeight;
        updatePreview();
        saveState();
    });
    
    elements.titleLetterSpacing.addEventListener('input', (e) => {
        currentState.title.letterSpacing = parseFloat(e.target.value);
        elements.titleLetterSpacingValue.textContent = currentState.title.letterSpacing;
        updatePreview();
        saveState();
    });
    
    elements.bodySize.addEventListener('input', (e) => {
        currentState.body.size = parseInt(e.target.value);
        elements.bodySizeValue.textContent = currentState.body.size;
        updatePreview();
        saveState();
    });
    
    elements.bodyLineHeight.addEventListener('input', (e) => {
        currentState.body.lineHeight = parseFloat(e.target.value);
        elements.bodyLineHeightValue.textContent = currentState.body.lineHeight;
        updatePreview();
        saveState();
    });
    
    elements.bodyLetterSpacing.addEventListener('input', (e) => {
        currentState.body.letterSpacing = parseFloat(e.target.value);
        elements.bodyLetterSpacingValue.textContent = currentState.body.letterSpacing;
        updatePreview();
        saveState();
    });
    
    elements.bodyMaxWidth.addEventListener('input', (e) => {
        currentState.maxWidth = parseInt(e.target.value);
        elements.bodyMaxWidthValue.textContent = currentState.maxWidth;
        updatePreview();
        saveState();
    });
    
    elements.captionSize.addEventListener('input', (e) => {
        currentState.caption.size = parseInt(e.target.value);
        elements.captionSizeValue.textContent = currentState.caption.size;
        updatePreview();
        saveState();
    });
    
    elements.captionLineHeight.addEventListener('input', (e) => {
        currentState.caption.lineHeight = parseFloat(e.target.value);
        elements.captionLineHeightValue.textContent = currentState.caption.lineHeight;
        updatePreview();
        saveState();
    });
    
    elements.captionLetterSpacing.addEventListener('input', (e) => {
        currentState.caption.letterSpacing = parseFloat(e.target.value);
        elements.captionLetterSpacingValue.textContent = currentState.caption.letterSpacing;
        updatePreview();
        saveState();
    });
    
    // Variable Font 슬라이더
    // Title
    elements.titleWght?.addEventListener('input', (e) => {
        if (!currentState.title.variableSettings) currentState.title.variableSettings = { wght: 700, wdth: 100, slnt: 0 };
        currentState.title.variableSettings.wght = parseInt(e.target.value);
        elements.titleWghtValue.textContent = currentState.title.variableSettings.wght;
        updatePreview();
        saveState();
    });
    
    elements.titleWdth?.addEventListener('input', (e) => {
        if (!currentState.title.variableSettings) currentState.title.variableSettings = { wght: 700, wdth: 100, slnt: 0 };
        currentState.title.variableSettings.wdth = parseInt(e.target.value);
        elements.titleWdthValue.textContent = currentState.title.variableSettings.wdth;
        updatePreview();
        saveState();
    });
    
    elements.titleSlnt?.addEventListener('input', (e) => {
        if (!currentState.title.variableSettings) currentState.title.variableSettings = { wght: 700, wdth: 100, slnt: 0 };
        currentState.title.variableSettings.slnt = parseInt(e.target.value);
        elements.titleSlntValue.textContent = currentState.title.variableSettings.slnt;
        updatePreview();
        saveState();
    });
    
    // Body
    elements.bodyWght?.addEventListener('input', (e) => {
        if (!currentState.body.variableSettings) currentState.body.variableSettings = { wght: 400, wdth: 100, slnt: 0 };
        currentState.body.variableSettings.wght = parseInt(e.target.value);
        elements.bodyWghtValue.textContent = currentState.body.variableSettings.wght;
        updatePreview();
        saveState();
    });
    
    elements.bodyWdth?.addEventListener('input', (e) => {
        if (!currentState.body.variableSettings) currentState.body.variableSettings = { wght: 400, wdth: 100, slnt: 0 };
        currentState.body.variableSettings.wdth = parseInt(e.target.value);
        elements.bodyWdthValue.textContent = currentState.body.variableSettings.wdth;
        updatePreview();
        saveState();
    });
    
    elements.bodySlnt?.addEventListener('input', (e) => {
        if (!currentState.body.variableSettings) currentState.body.variableSettings = { wght: 400, wdth: 100, slnt: 0 };
        currentState.body.variableSettings.slnt = parseInt(e.target.value);
        elements.bodySlntValue.textContent = currentState.body.variableSettings.slnt;
        updatePreview();
        saveState();
    });
    
    // Caption
    elements.captionWght?.addEventListener('input', (e) => {
        if (!currentState.caption.variableSettings) currentState.caption.variableSettings = { wght: 400, wdth: 100, slnt: 0 };
        currentState.caption.variableSettings.wght = parseInt(e.target.value);
        elements.captionWghtValue.textContent = currentState.caption.variableSettings.wght;
        updatePreview();
        saveState();
    });
    
    elements.captionWdth?.addEventListener('input', (e) => {
        if (!currentState.caption.variableSettings) currentState.caption.variableSettings = { wght: 400, wdth: 100, slnt: 0 };
        currentState.caption.variableSettings.wdth = parseInt(e.target.value);
        elements.captionWdthValue.textContent = currentState.caption.variableSettings.wdth;
        updatePreview();
        saveState();
    });
    
    elements.captionSlnt?.addEventListener('input', (e) => {
        if (!currentState.caption.variableSettings) currentState.caption.variableSettings = { wght: 400, wdth: 100, slnt: 0 };
        currentState.caption.variableSettings.slnt = parseInt(e.target.value);
        elements.captionSlntValue.textContent = currentState.caption.variableSettings.slnt;
        updatePreview();
        saveState();
    });
    
    // 샘플 텍스트 토글
    elements.sampleKo.addEventListener('click', () => {
        currentState.sampleLang = 'ko';
        elements.sampleKo.classList.add('active');
        elements.sampleEn.classList.remove('active');
        updatePreview();
        saveState();
    });
    
    elements.sampleEn.addEventListener('click', () => {
        currentState.sampleLang = 'en';
        elements.sampleEn.classList.add('active');
        elements.sampleKo.classList.remove('active');
        updatePreview();
        saveState();
    });
    
    // 커스텀 텍스트 토글
    elements.useCustomText.addEventListener('change', (e) => {
        if (e.target.checked) {
            elements.customTextInput.style.display = 'flex';
            if (elements.customTitleText.value || elements.customBodyText.value || elements.customCaptionText.value) {
                currentState.sampleText = {
                    title: elements.customTitleText.value,
                    body: elements.customBodyText.value,
                    caption: elements.customCaptionText.value
                };
            }
        } else {
            elements.customTextInput.style.display = 'none';
            currentState.sampleText = null;
        }
        updatePreview();
        saveState();
    });
    
    // 커스텀 텍스트 입력
    elements.customTitleText.addEventListener('input', () => {
        if (!currentState.sampleText) currentState.sampleText = {};
        currentState.sampleText.title = elements.customTitleText.value;
        updatePreview();
        saveState();
    });
    
    elements.customBodyText.addEventListener('input', () => {
        if (!currentState.sampleText) currentState.sampleText = {};
        currentState.sampleText.body = elements.customBodyText.value;
        updatePreview();
        saveState();
    });
    
    elements.customCaptionText.addEventListener('input', () => {
        if (!currentState.sampleText) currentState.sampleText = {};
        currentState.sampleText.caption = elements.customCaptionText.value;
        updatePreview();
        saveState();
    });
    
    // 배경색
    elements.bgColor.addEventListener('input', (e) => {
        currentState.bgColor = e.target.value;
        elements.bgColorText.value = e.target.value;
        updatePreview();
        saveState();
    });
    
    elements.bgColorText.addEventListener('input', (e) => {
        const value = e.target.value;
        if (/^#[0-9A-F]{6}$/i.test(value)) {
            currentState.bgColor = value;
            elements.bgColor.value = value;
            updatePreview();
            saveState();
        }
    });
    
    // 테마 토글
    elements.themeToggle.addEventListener('click', () => {
        currentState.theme = currentState.theme === 'dark' ? 'light' : 'dark';
        document.body.setAttribute('data-theme', currentState.theme);
        saveState();
    });
    
    // Export
    elements.exportBtn.addEventListener('click', exportCSS);
    
    // 프리셋 저장
    elements.savePresetBtn.addEventListener('click', savePreset);
    
    elements.presetName.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            savePreset();
        }
    });
    
    // 추천 기능
    elements.recommendBtn.addEventListener('click', () => {
        renderRecommendations();
        elements.recommendationsPanel.style.display = 'flex';
    });
    
    elements.closeRecommendations.addEventListener('click', () => {
        elements.recommendationsPanel.style.display = 'none';
    });
    
    // 백그라운드 클릭 시 패널 닫기
    elements.recommendationsPanel.addEventListener('click', (e) => {
        if (e.target === elements.recommendationsPanel) {
            elements.recommendationsPanel.style.display = 'none';
        }
    });
    
    // 레이아웃 프리셋
    document.getElementById('layout-newspaper')?.addEventListener('click', () => {
        applyLayoutPreset('newspaper');
    });
    
    document.getElementById('layout-branding')?.addEventListener('click', () => {
        applyLayoutPreset('branding');
    });
    
    document.getElementById('layout-subtitle')?.addEventListener('click', () => {
        applyLayoutPreset('subtitle');
    });
}

// 전역 함수로 노출 (프리셋 카드에서 호출)
window.loadPreset = loadPreset;
window.deletePreset = deletePreset;
window.editPreset = editPreset;

// 초기화
document.addEventListener('DOMContentLoaded', () => {
    loadState();
    setupEventListeners();
});

