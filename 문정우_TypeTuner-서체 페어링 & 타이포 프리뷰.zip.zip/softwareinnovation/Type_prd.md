# TypeTuner — 서체 페어링 & 타이포 프리뷰 툴 PRD v1.0

## 1) 배경 & 목표
- 디자인 과제/브랜딩 작업에서 **제목·본문·캡션** 조합을 빠르게 시험하고, 가독성/대비를 확인한 뒤 **CSS 스니펫으로 내보내기**까지 필요한 경우가 많음.  
- 본 프로젝트는 브라우저에서 동작하는 **경량 웹 툴**로, **폰트 페어링 추천 → 라이브 프리뷰 → 가독성 체크 → CSS 내보내기**를 한 흐름으로 제공한다.

## 2) 타겟 사용자
- 디자인 학부생/초심자, 개인 브랜드·포트폴리오 제작자, UI 기초 수업 수강생.

## 3) 핵심 가치(Why it matters)
- 감에만 의존하지 않고 **룰 기반 추천**으로 초안을 빠르게 만들고,  
- **실제 과제/시안에 바로 쓰는 코드(CSS/Google Fonts 링크)**를 얻을 수 있다.  
- **가독성/대비** 지표로 결정 근거를 명확히 설명 가능(발표·리포트에 유리).

## 4) 범위(Scope)
### MVP 기능 (Step 3에서 구현)
- [F1] **폰트 선택/추천**: 제목(H1), 본문(Body), 캡션(Caption) 슬롯에 폰트 지정.  
- [F2] **라이브 프리뷰**: 한국어/영문 샘플 텍스트 토글 + 사용자 입력.  
- [F3] **타이포 컨트롤**: 크기, 행간(line-height), 자간(letter-spacing), 본문 열폭(max-width).  
- [F4] **가독성/대비 체크**: 본문 크기/행간 최소 가이드, 텍스트–배경 대비(대략적 WCAG 점검).  
- [F5] **내보내기**: 선택 조합을 CSS 및 Google Fonts `<link>`/`@import` 스니펫으로 복사.  
- [F6] **로컬 저장**: 즐겨찾기 프리셋 저장/불러오기(localStorage).

### 추가 기능 (Step 4에서 확장)
- [A1] **룰/유사도 기반 페어링 추천 버튼**: *세리프 헤드라인 + 산세리프 본문* 등 규칙과 점수화로 상위 3조합 제안.  
- [A2] **Variable font 축 슬라이더**: weight/width/slant 노출(지원 폰트일 때만).  
- [A3] **레이아웃 프리셋**: “신문형/브랜딩형/자막형” 버튼으로 빠른 레이아웃.  
- [A4] **다크/라이트 테마 토글**.

### 디자인 개선 (Step 5에서 진행)
- 카드형 UI, 반응형(모바일 360px~ 데스크톱), 명확한 시각 계층(H1 > Body > Caption), 키보드 포커스/명확한 Hover.

## 5) 사용자 흐름(UX Flow)
1. 좌측: **폰트 슬롯(Title/Body/Caption)** + 추천 버튼  
2. 중앙: **프리뷰 캔버스** (샘플 텍스트/사용자 텍스트 전환, 배경색 선택)  
3. 우측: **타이포 컨트롤** (크기/행간/자간/열폭) + **경고 배지** (가독성/대비) + **Export**  
4. 하단: **Saved Presets**(저장/불러오기/삭제)

## 6) 데이터 모델
```ts
type FontSlot = 'title' | 'body' | 'caption';

interface TypeSetting {
  fontFamily: string;       // 예: 'Noto Sans KR'
  size: number;             // px
  lineHeight: number;       // 단위 없는 계수(예: 1.6)
  letterSpacing: number;    // em 단위 권장(예: 0, 0.02)
  weight?: number | string; // 400, 700 등
}

interface PairingState {
  title: TypeSetting;
  body: TypeSetting;
  caption: TypeSetting;
  theme: 'dark' | 'light';
  bgColor: string;          // '#0e0f10' 등
  sampleLang: 'ko' | 'en';
  sampleText?: string;
  maxWidth: number;         // 본문 열폭(px)
}

interface Preset {
  id: string;               // uuid
  name: string;
  state: PairingState;
  createdAt: number;
  updatedAt: number;
}

localStorage['typetuner-presets'] = Preset[];
```

## 7) 페어링 추천 규칙(경량 “AI” 로직)
- **기본 룰**:  
  - 헤드라인(Title)은 **세리프/디스플레이**, 본문은 **산세리프** 선호.  
  - x-height 높은 본문 서체 + 대비 명확한 헤드라인 가점.  
  - weight 대비(Title > Body) 가점, 레터폭(Width) 조합 균형.  
- **점수식(간단 가중치 예시)**  
  - PairScore = Base + SerifMix(1~2) + WeightContrast(0~2) + XHeightContrast(0~2) + CategoryDiversity(0~1).  
- **출력**: 상위 3조합을 카드로 제안(“추천 이유” 배지 함께 노출).

## 8) 가독성/대비 체크(라이트 규칙)
- 본문 기본: `16px 이상`, `line-height ≥ 1.5`, `max-width 45–75ch` 권장.  
- 대비: 텍스트와 배경 간 **상대 명도**로 대략 점검(엄밀 WCAG는 아님) → 경고 배지 표시.

## 9) 화면요구(간략 와이어)
- 헤더: 프로젝트명, 테마 토글, Export 버튼  
- 좌 패널: 폰트 선택 드롭다운(또는 입력), 추천 버튼  
- 중앙: 프리뷰(Title/Body/Caption 블록) + 배경색 선택  
- 우 패널: 슬라이더(크기/행간/자간/열폭), 경고 배지, Preset 저장/불러오기

## 10) 기술 스택 & 제약
- **Vanilla HTML/CSS/JS** (프레임워크 X)  
- 폰트는 우선 **Google Fonts**에서 로드(한국어/영문 지원 폰트 위주)  
- 성능: 초기 로드 < 1s(폰트 2~3종), 프리뷰 인풋 반응 < 50ms  
- 접근성: 키보드 포커스 가능, 레이블/aria 제공, 대비 경고

## 11) 내보내기 사양(Export)
- **CSS**: `@import`(또는 `<link>`) + `:root`에 폰트 변수 + `.tt-title`, `.tt-body`, `.tt-caption` 규칙  
- **예시 아웃풋**
```css
/* Google Fonts */
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;700&family=Merriweather:wght@700&display=swap');

:root{
  --tt-title: 'Merriweather', serif;
  --tt-body: 'Noto Sans KR', sans-serif;
  --tt-caption: 'Noto Sans KR', sans-serif;
}

.tt-title{ font-family: var(--tt-title); font-size: 42px; line-height: 1.2; letter-spacing: 0; font-weight: 700; }
.tt-body{ font-family: var(--tt-body); font-size: 16px; line-height: 1.6; letter-spacing: 0.01em; }
.tt-caption{ font-family: var(--tt-caption); font-size: 13px; line-height: 1.4; letter-spacing: 0.02em; color: #8b8f98; }
```

## 12) 수용 기준(Acceptance Criteria)
- [AC1] 폰트 2~3종 선택 후 프리뷰 텍스트가 즉시 반영된다.  
- [AC2] 크기/행간/자간/열폭 조절이 실시간 반영된다.  
- [AC3] 대비/가독성 경고가 조건에서 정상적으로 노출된다.  
- [AC4] Export 버튼 클릭 시 CSS/링크 스니펫이 복사된다.  
- [AC5] Preset 저장/불러오기/삭제가 동작한다.

## 13) 비범위(Out of Scope)
- 서버/회원가입, 클라우드 동기화, 정교한 WCAG 계산, 상용 폰트 라이선스 관리.

## 14) 샘플 텍스트
- **KR:** “타이포그래피는 콘텐츠의 숨결을 다스리는 디자인의 문법이다.”  
- **EN:** “Typography sets the rhythm of reading and the tone of brand voice.”

---

### Cursor용 프롬프트(복사해 사용)
- **초기 코드 생성:**  
`@PRD 문서를 참고해서 TypeTuner(바닐라 JS) MVP를 index.html, style.css, app.js 3파일로 구현해줘. F1~F6을 포함하고, 좌/중앙/우 패널 레이아웃과 프리뷰/컨트롤/Export/로컬저장까지 동작하게 만들어.`

- **추가 기능(차후):**  
`룰/유사도 기반 페어링 추천(A1) 로직을 추가하고, 상위 3조합 카드와 ‘추천 이유’ 배지를 표시해줘.`
